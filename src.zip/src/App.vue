<template>
    <div>
        <iv-visualisation :title="projectName">
            <h3 style="margin-left:5vh;">FRF and Time history plot of your desired forcing frequency</h3>
            <h4 style="margin-left:5vh;">Please choose an excitation frequency using the slider below</h4>
            
            <div style="margin:5vh;" id="flexContainer">
                <div id="innerFlex1">
                    <iv-slider name="Excitation Frequency (Hz):"  ref="wSlider" min=0.01 :max=wlim init_val=10 @sliderChanged="updateSlider" :value=wSlider></iv-slider>
                    <div id='graph'></div>
                </div>
                <div id="innerFlex2">
                    <br><br><br><br>
                    <div id='graph2' ></div>
                </div> 
            </div>

            <div style="margin:5vh;"> 

                <div style="margin:20px;" v-show="wdHz">
                    
                    <h5>System Parameters:</h5>
                    <p style="font-size:15px" class="small">
                    Natural Frequency, ω<sub>n</sub> (rad/s): {{ wn }} rad/s
                    <br>
                    Natural Frequency, ω<sub>n</sub> (Hz): {{ wnHz }} Hz
                    <br>
                    Damped Natural Frequency, ω<sub>d</sub> (rad/s): {{ wd }} rad/s 
                    <br>
                    Damped Natural Frequency, ω<sub>d</sub> (Hz): {{ wdHz }} Hz
                    </p>
                </div>

                <div style="margin:20px;" v-show="!wdHz">
                    
                    <h5>System Parameters:</h5>
                    <p style="font-size:15px" class="small">
                    Natural Frequency, ω<sub>n</sub> (rad/s): {{ wn }} rad/s
                    <br>
                    Natural Frequency, ω<sub>n</sub> (Hz): {{ wnHz }} Hz
                    </p>
                </div>
            </div>

            <template #hotspots>
                <iv-pane position="left" @paneResize="update" @paneToggle="update">
                    <iv-sidebar-content style="font-size:12px" nextText="Vib. Iso." previousText="Forced">
                        <iv-sidebar-section title="Base Excitation">
                            <img src="./assets/BaseExcitation.png" class="centre" style="width:8vw;">
                            <p style="font-size:14px" class="small">Base excitation deals with vibration excitation generated via the base; the SDOF system now involves two components, both the mass and the base, moving relative to each other. The equation of motion for the system is a linear ODE with constant coefficients:</p>
                            <img src="./assets/EoM1.png" style="width:12vw;">
                            <p style="font-size:14px" class="small">The motion transmissibility of the system (receptance) is the ratio between the displacements of the mass and the base, found via the following equation.</p>
                            <img src="./assets/EoM2.png" style="width:13vw;">
                            <p style="font-size:14px" class="small">Observe how the initial displacement of the base and the excitation frequency influence the transmissibility of the system.</p>
                            <!-- This Base Excitation solver takes in your parameters and then produces a motion transmissibility curve. You can then choose a frequency to view the time history plot at that specific frequency. Try it out by changing the input parameters and viewing your solution. To submit feedback for this module please click                            
                            <a href="https://forms.gle/W4DmoEKuGnu2RkWN6" target="_blank">here.</a>                   -->
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <iv-pane position="right" :allowResize=false>
                    <div style="margin-top:0px; padding:20px;" >
                        <h5>Desired Plots</h5>
                        <form>
                            <p style="font-size:15px" class="small"><input type="radio" id="plot1" value="1" v-model="displaysplot" @change="update" checked>
                            <label for="plot1">Displacement (Receptance)</label>
                            <br>
                            <input type="radio" id="plot2" value="2" v-model="displaysplot" @change="update">
                            <label for="plot2">Velocity (Mobility)</label>
                            <br>
                            <input type="radio" id="plot3" value="3" v-model="displaysplot" @change="update">
                            <label for="plot3">Acceleration (Accelerance)</label></p>
                        </form>
                        <!-- <h5>Desired FRF Plot</h5>
                        <form>
                            <input type="radio" id="plot1" value="1" v-model="displaysplot2" @change="update" checked>
                            <label for="plot1">Receptance</label>
                            <br>
                            <input type="radio" id="plot2" value="2" v-model="displaysplot2" @change="update">
                            <label for="plot2">Mobility</label>
                            <br>
                            <input type="radio" id="plot3" value="3" v-model="displaysplot2" @change="update">
                            <label for="plot3">Accelerance</label>
                            <br>
                        </form> -->
                        <h5>System Parameters</h5>
                        <p style="font-size:15px" class="small"><label>Mass, m (kg)</label>
                        <br>
                        <input v-model="mass" @change="update">
                        <br>
                        <label>Spring Constant, k (N/m)</label>
                        <br>
                        <input v-model="springConst"  @change="update">
                        <br>
                        <label>Use Damping Coefficient</label>
                        <br>
                        <iv-toggle-basic @input="dampToggle"></iv-toggle-basic>
                        <label v-show="!showCoeff" >Damping Ratio, ζ</label>
                        <label v-show="showCoeff">Damping Coefficient, c (Ns/m)</label>
                        <br>
                        <input v-model="dampRatio"  @change="updateDampRatio" v-show="!showCoeff">
                        <input v-model="dampCoeff"  @change="updateDampCoeff"  v-show="showCoeff"></p>

                        <h5>Initial Conditions</h5>

                        <p style="font-size:15px" class="small"><label>Base Amplitude, y<sub>0</sub> (m)</label>
                        <br>
                        <input v-model="forceAmp"  @change="update"></p>
                        
                        <h5>Computational Parameters</h5>
                        <p style="font-size:15px" class="small"><label>ω Axis Limit, ω (Hz)</label>
                        <br>
                        <input v-model="wlim"  @change="update"></p>

                        <br>
                    </div>
                </iv-pane>
                
                <!-- <iv-fixed-hotspot position="topright" style="width:300px; z-index:2" transparent>
                    
                </iv-fixed-hotspot> -->
            </template>

        
        </iv-visualisation>
    </div>
</template>
<script>
import Plotly from 'plotly.js/dist/plotly.min.js'; // eslint-disable-line no-unused-vars

export default {
    name:"App",
    data(){
        return {
            projectName: 'Vibrations App - Base Excitation',
            mass: 1,
            dampRatio: 0.1,
            initDisp:0.1,
            timeSpan:2,
            springConst: 1000,
            dampCoeff:6.325,
            numPoints:1000,
            wlim: 40,
            wSlider: 10,
            updatePlot: true,
            wn: 32,
            wnHz: 5,
            wd: 31,
            wdHz: 5,
            forceAmp: 0.1,
            maxAmp: 0.1,
            showText: true,
            showCoeff: false,
            displaysplot: "1",
            displaysplot2: "1"
        }
    },
    methods: {
        update(){
            if(this.mass <= 0){
                window.alert("Mass must be greater than 0.");
                this.mass = 1;
            }
            if(this.springConst <= 0){
                window.alert("Spring constant must be greater than 0.");
                this.springConst = 1000;
            }
            if(this.timeSpan <= 0){
                window.alert("Time span must be greater than 0.");
                this.springConst = 1000;
            }
            if(this.numPoints <= (2*this.wnHz * this.timeSpan)){
                window.alert(`Please ensure your sampling frequency (Number of Points/Time Span), ${this.numPoints/this.timeSpan} Hz, is well above double the natural frequency of the system, ${this.wnHz} Hz. This is to prevent aliasing from occuring. We recommend increasing the number of points beyond ${4*this.wnHz * this.timeSpan} points.`);
                this.numPoints = (4*this.wnHz * this.timeSpan);
            }
            if(this.wSlider > this.wlim){
                this.$refs.wSlider.reset();
            }
            if(this.wlim < 0.1){
                window.alert("Omega limit must be greater 0.1 Hz.");
                this.wlim = 0.1;
            }

            console.log('update');

            this.updatePlot = true;
        },
        updateSlider(e){
            this.wSlider = e;
            this.updatePlot = true;
        },
        updateDampCoeff(){
            if(this.dampCoeff < 0){
                window.alert("Damping coefficient must be greater than 0.");
                this.dampCoeff = 6.325;
            }
            this.dampRatio = Math.round( (this.dampCoeff / (2*Math.sqrt(this.springConst * this.mass))) *1000 )/1000;
            this.updatePlot = true;
        },
        updateDampRatio(){
            if(this.dampRatio < 0 || this.dampRatio > 2){
                window.alert("Damping ratio must be greater than 0 and less than or equal to 2.");
                this.dampRatio = 0.1;
            }
            this.dampCoeff = Math.round( (this.dampRatio *2 * Math.sqrt(this.springConst * this.mass) )*1000)/1000;
            this.updatePlot = true;
        },
        dampToggle(){
            this.showCoeff = !this.showCoeff;
        },
    },
    mounted(){
        let vm = this; // eslint-disable-line no-unused-vars

        let config = {responsive: true};

        function FRF_Solver(){

            let m = vm.mass;
            let k = vm.springConst;
            let wn = Math.sqrt(k / m);
            let dampRatio = Number(vm.dampRatio);
            let c = vm.dampCoeff;
            let wAxisLimit = vm.wlim;
            let wHz_axis = [];
            let w = [];
            let r = [];
            let Tamp = [];
            let Mobi = [];
            let Accel = [];
            let phase = [];
            let phase2 = [];
            let phase3 = [];
            let phi = [];
            let alpha;

            c = dampRatio * 2 * Math.sqrt(k * m)

            for(let i = 0; i < wAxisLimit; i = i + wAxisLimit/1000){
                wHz_axis.push(i);
                w.push(i * 2 * Math.PI);
                r.push(i * 2 * Math.PI / wn);
                // Tamp.push(1 / Math.sqrt((k - m * (2 * Math.PI * i) ** 2) ** 2 + (c * 2 * Math.PI * i) ** 2));
                // phase.push((Math.atan2(-c * (2 * Math.PI * i), (k - m * (2 * Math.PI * i) ** 2)))*180/Math.PI);
            }

            for(let i = 0; i < w.length; i++){
                Tamp.push(Math.sqrt((k**2 + (c*w[i])**2)/((k - m * w[i] ** 2) ** 2 + (c * w[i]) ** 2)));
                Mobi.push(i * Math.sqrt((k**2 + (c*w[i])**2)/((k - m * w[i] ** 2) ** 2 + (c * w[i]) ** 2)));
                Accel.push((i**2) * Math.sqrt((k**2 + (c*w[i])**2)/((k - m * w[i] ** 2) ** 2 + (c * w[i]) ** 2)));

                alpha = Math.atan(c * w[i] / k);
                
                if(m * w[i] **2 > k){
                    phi.push(Math.atan(c * w[i] / (k - m * w[i] ** 2)) + Math.PI);
                } else {
                    phi.push(Math.atan(c * w[i] / (k - m * w[i] ** 2)));
                }

                phase.push(-(phi[i] - alpha) * 180/Math.PI);
                phase2.push(90 - (phi[i] - alpha) * 180/Math.PI);
                phase3.push(180 - (phi[i] - alpha) * 180/Math.PI);
            }

            

            return [wHz_axis, Tamp, phase, Mobi, phase2, Accel, phase3]
        }

        function ForceTransmissibilityTimeHistorySolver(){
            
            let m = vm.mass;
            let k = vm.springConst;
            let dampRatio = Number(vm.dampRatio);
            let Famp = vm.forceAmp;
            let wHz = vm.wSlider;
            let c = vm.dampCoeff; 
            let w = 2 * Math.PI * wHz; // Conv Forced freq from Hz into rad/s
            let t = [];
            let F = [];
            let Ft = [];
            let phi;
            let d = vm.displaysplot;
            let d2 = vm.displaysplot2;

            let wn = Math.sqrt(k / m);  // Natural Freq of spring mass system
            let wnHz = wn/(2*Math.PI);    // Natural freq in Hz

            let wd = wn * Math.sqrt(1 - dampRatio ** 2);  // Damped frequency
            let wdHz = wd/(2*Math.PI);

            // Work out Nice time frame using decay to 1%
            let f = wHz;
            let t_one_wave = 1/f;
            let tend = t_one_wave * 6;
            
            for(let i = 0; i < tend; i = i + tend/1000){
                t.push(i);
            }

            // Solving for Complete Forced Solution
            let Tamp = Math.sqrt((k**2 + (c*w)**2)/((k - m * w ** 2) ** 2 + (c * w) ** 2));

            if (m * w ** 2 > k){
                phi = Math.atan(c * w / (k - m * w ** 2)) + Math.PI;
            }else{
                phi = Math.atan(c * w / (k - m * w ** 2));
            }

            let alpha = Math.atan(c * w / k);
            // Working out Phase
            // theta = phi + alpha         # + alpha as Phi is negative
            let phase = phi - alpha;

            // USING TEXT BOOK EQUTION FOR PHASE
            //phase = np.arctan(2*dampRatio*w**3 / wn**3 /(1-(1-4*dampRatio**2)*w**2/wn**2))
            
            let vel = [];
            let velT = [];
            let acc = [];
            let accT = [];
            // F is the Base Displacement, Ft is the Mass Displacement
            for(let i = 0; i < t.length; i++){
                F.push(Famp * Math.sin(w * t[i]));
                Ft.push(Tamp * Famp * Math.sin(w * t[i] - phase));
                vel.push(Famp * Math.sin(w * (t[i] + t_one_wave/4)));
                velT.push(Tamp * Famp * Math.sin(w * (t[i] + t_one_wave/4) - phase));
            }
            
            for(let i = 0; i < t.length; i++){
                vel[i] = vel[i] * wd
                velT[i] = velT[i] * wd
                acc[i] = - F[i] * wd**2
                accT[i] = - Ft[i] * wd**2
            }

            vm.wn = Math.round(wn*100)/100;
            vm.wnHz = Math.round(wnHz*100)/100;
            vm.wd =  Math.round(wd * 100)/100;
            vm.wdHz = Math.round(wdHz * 100)/100;    

            return [t, F, Ft, vel, velT, acc, accT, d, d2]
        }

        function update(){
            requestAnimationFrame(update);

            if(vm.updatePlot ){
                vm.updatePlot = false;
                
                let data = ForceTransmissibilityTimeHistorySolver();
                let data2 = FRF_Solver();

                let max1 = data2[1].reduce(function(a,b) {
                    return Math.max(a,b)
                });
                let min1 = data2[1].reduce(function(a,b) {
                    return Math.min(a,b)
                });
                let max2 = data2[3].reduce(function(a,b) {
                    return Math.max(a,b)
                });
                let min2 = data2[3].reduce(function(a,b) {
                    return Math.min(a,b)
                });

                let max3 = data2[5].reduce(function(a,b) {
                    return Math.max(a,b)
                });
                let min3 = data2[5].reduce(function(a,b) {
                    return Math.min(a,b)
                });

                /* let absx = [];
                let absxt = [];
                let absv = [];
                let absvt = [];
                let absa = [];
                let absat = [];
                for (let i = 0; i < data[1].length; i++) {
                    absx.push(Math.abs(data[1][i]));
                    absv.push(Math.abs(data[3][i]));
                    absa.push(Math.abs(data[5][i]));
                    absxt.push(Math.abs(data[2][i]));
                    absvt.push(Math.abs(data[4][i]));
                    absat.push(Math.abs(data[6][i]));
                }
                let maxx = absx.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxv = absv.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxa = absa.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxxt = absxt.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxvt = absvt.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxat = absat.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity); */

                let layout = {
                    xaxis: {title:"Time (sec)"},
                yaxis: {
                    title:"Displacement Amplitude (m)",
                },
                font: {
                        color: "#003E74",
                        weight: 900
                },
                legend: {
                    bgcolor: 'rgba(0,0,0,0.2)',
                    x: 1,
                    xanchor: 'right',
                    y: 1.2
                }
                };
                
                let layout3 = {
                    xaxis: {title:"Time (sec)"},
                yaxis: {
                    title:"Velocity Amplitude (m/s)",
                },
                font: {
                        color: "#003E74",
                        weight: 900
                },
                legend: {
                    bgcolor: 'rgba(0,0,0,0.2)',
                    x: 1,
                    xanchor: 'right',
                    y: 1.2
                }
                };

                let layout4 = {
                    xaxis: {title:"Time (sec)"},
                yaxis: {
                    title:"Acceleration Amplitude (m/s<sup>2</sup>)",
                },
                font: {
                        color: "#003E74",
                        weight: 900
                },
                legend: {
                    bgcolor: 'rgba(0,0,0,0.2)',
                    x: 1,
                    xanchor: 'right',
                    y: 1.2
                }
                };

                let layout2 = {
                    xaxis: {title:"Excitation frequency (Hz)"},
                    yaxis: {
                        title:"T = x<sub>0</sub>/y<sub>0</sub> (-)",
                    },
                    yaxis2: {
                        title:"Phase (Degrees)",
                        overlaying: 'y',
                        side: 'right',
                        showgrid: false,
                    },
                    font: {
                            color: "#003E74",
                            weight: 900
                    },
                    legend: {
                        bgcolor: 'rgba(0,0,0,0.2)',
                        x: 1,
                        xanchor: 'right',
                        y: 1.2,
                    }
                };

                let layout5 = {
                    xaxis: {title:"Excitation frequency (Hz)"},
                    yaxis: {
                        title:"T = x&#775;<sub>0</sub>/&#7823;<sub>0</sub> (-)",
                    },
                    yaxis2: {
                        title:"Phase (Degrees)",
                        overlaying: 'y',
                        side: 'right',
                        showgrid: false,
                    },
                    font: {
                            color: "#003E74",
                            weight: 900
                    },
                    legend: {
                        bgcolor: 'rgba(0,0,0,0.2)',
                        x: 1,
                        xanchor: 'right',
                        y: 1.2,
                    }
                };

                let layout6 = {
                    xaxis: {title:"Excitation frequency (Hz)"},
                    yaxis: {
                        title:"T = &#7821;<sub>0</sub>/&#255;<sub>0</sub> (-)",
                    },
                    yaxis2: {
                        title:"Phase (Degrees)",
                        overlaying: 'y',
                        side: 'right',
                        showgrid: false,
                    },
                    font: {
                            color: "#003E74",
                            weight: 900
                    },
                    legend: {
                        bgcolor: 'rgba(0,0,0,0.2)',
                        x: 1,
                        xanchor: 'right',
                        y: 1.2,
                    }
                };

                if (data[7] == "1"){
                    Plotly.newPlot('graph', [{
                        x: data2[0],
                        y: data2[1],
                        line: {simplify: false},
                        mode: 'lines',
                        name: "Amplitude"
                    },
                    {
                        x: data2[0],
                        y: data2[2],
                        line: {simplify: false},
                        mode: 'lines',
                        name: "Phase", 
                        yaxis: 'y2'
                    },
                    {
                        x: [vm.wSlider, vm.wSlider],
                        y: [min1, max1],
                        mode: 'lines',
                        showlegend: false,
                        line: {
                            dash: 'dashdot',
                            color: 'red'
                        }

                    }],
                    layout2,
                    config
                    )
                }
                
                if (data[7] == "2"){
                    Plotly.newPlot('graph', [{
                        x: data2[0],
                        y: data2[3],
                        line: {simplify: false, color: 'rgb(152,66,245)'},
                        mode: 'lines',
                        name: "Amplitude"
                    },
                    {
                        x: data2[0],
                        y: data2[4],
                        line: {simplify: false},
                        mode: 'lines',
                        name: "Phase", 
                        yaxis: 'y2'
                    },
                    {
                        x: [vm.wSlider, vm.wSlider],
                        y: [min2, max2],
                        mode: 'lines',
                        showlegend: false,
                        line: {
                            dash: 'dashdot',
                            color: 'red'
                        }

                    }],
                    layout5,
                    config
                    )
                }

                if (data[7] == "3"){
                    Plotly.newPlot('graph', [{
                        x: data2[0],
                        y: data2[5],
                        line: {simplify: false, color: 'rgb(101,201,104)'},
                        mode: 'lines',
                        name: "Amplitude"
                    },
                    {
                        x: data2[0],
                        y: data2[6],
                        line: {simplify: false},
                        mode: 'lines',
                        name: "Phase", 
                        yaxis: 'y2'
                    },
                    {
                        x: [vm.wSlider, vm.wSlider],
                        y: [min3, max3],
                        mode: 'lines',
                        showlegend: false,
                        line: {
                            dash: 'dashdot',
                            color: 'red'
                        }

                    }],
                    layout6,
                    config
                    )
                }
                
                if (data[7] == "1"){
                    Plotly.newPlot('graph2', [
                    {
                    x : data[0],
                    y : data[2],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Mass displacement, x"
                    },
                    {
                    x : data[0],
                    y : data[1],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Base displacement, y"
                    }],
                    layout,
                    config
                    )
                }

                if (data[7] == "2"){
                    Plotly.newPlot('graph2', [
                    {
                    x : data[0],
                    y : data[4],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Mass velocity, x&#775;"
                    },
                    {
                    x : data[0],
                    y : data[3],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Base velocity, &#7823;"
                    }],
                    layout3,
                    config
                    )
                }

                if (data[7] == "3"){
                    Plotly.newPlot('graph2', [
                    {
                    x : data[0],
                    y : data[6],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Mass acceleration, &#7821;"
                    },
                    {
                    x : data[0],
                    y : data[5],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Base acceleration, &#255;"
                    }],
                    layout4,
                    config
                    )
                }
                
            }

        }

        update();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
html{
    overflow: hidden;
}
.iv-pane-right{
    overflow: auto;
}
p.small {
  line-height: 1.5;
}
img.centre {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
#graph {
    z-index:-2;
}
@media screen and (orientation: portrait) {
    #innerFlex1 {
        width:20vw;
        min-width: 300px;
        flex-grow: 1;
    }
    #innerFlex2 {
        width: 30vw;
        min-width: 300px;
        flex-grow: 1;
    }
    #flexContainer {
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;

    }
}

@media screen and (orientation: landscape) {
    /* #graph {
        width:25vw; height:400px;
    }
    #graph2 {
        width:25vw; height: 400px;
    } */
    #innerFlex1 {
        width:40%;
        min-width: 300px;
        flex-grow: 1;
    }
    #innerFlex2 {
        width: 50%;
        min-width: 300px;
        flex-grow: 2;
    }
    #flexContainer {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;

    }
}
</style>